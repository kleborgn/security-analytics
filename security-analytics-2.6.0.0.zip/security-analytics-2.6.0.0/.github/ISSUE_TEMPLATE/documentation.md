**Is your feature request related to a problem?**
A new feature has been added.

**What solution would you like?**
Document the usage of the new feature.

**What alternatives have you considered?**
N/A

**Do you have any additional context?**
_Add any other context or screenshots about the feature request here._
