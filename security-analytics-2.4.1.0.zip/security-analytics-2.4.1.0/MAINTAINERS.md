## Maintainers
| Maintainer             | GitHub ID                                       | Affiliation |
|------------------------|-------------------------------------------------| ----------- |
| Saurabh Singh          | [getsaurabh02](https://github.com/getsaurabh02) | Amazon |
| Subhobrata Dey         | [sbcd90](https://github.com/sbcd90)             | Amazon |
| Surya Sashank Nistalai | [eirsep](https://github.com/eirsep)             | Amazon |


[This document](https://github.com/opensearch-project/.github/blob/main/MAINTAINERS.md) explains what maintainers do in this repo, and how they should be doing it. If you're interested in contributing, see [CONTRIBUTING](CONTRIBUTING.md).