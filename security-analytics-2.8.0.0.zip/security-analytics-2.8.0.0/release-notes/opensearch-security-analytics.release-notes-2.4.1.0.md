## Version 2.4.1.0 Release Notes

Compatible with OpenSearch 2.4.1

### Bug Fixes

* fix for running windows integration tests ([#176](https://github.com/opensearch-project/security-analytics/pull/176))